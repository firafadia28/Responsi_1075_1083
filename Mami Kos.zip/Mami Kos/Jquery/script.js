$(document).ready(function(){
    $(".login").click(function(){
        $(".pilihan").toggle();
    });
});

$(document).ready(function(){
	$('.hiden-button').click(function(){
		$('.hiden-menu').toggleClass("slide-hiden-menu-tampil");
	});
});